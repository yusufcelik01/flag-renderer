#ifndef __FLAG__HELPERS__
#define __FLAG__HELPERS__
#include <glm/glm.hpp> // GL Math library header

unsigned char* load_image(char* img, int* width, int* height, int* nrChannels);

//glm::vec3 mirrorPoint(glm::vec3 mirror, glm::vec3 p);

#endif //__FLAG__HELPERS__
